// import { Request, Response } from 'express';
// import asyncHandler from 'express-async-handler';
// import Category from '../models/categoryModel';
// import multer from "multer";

// //Get All Categories
// const getAllCategories = asyncHandler(async (req: Request, res: Response) => {
// const category = await Category.find();
// res.status(200).json(category);
// });

// // Get category by ID
// const getCategoryById = asyncHandler(async (req: Request, res: Response) => {
//     const category = await Category.findById(req.params.id);
//     if (!category) {
//         res.status(404);
//         throw new Error("category not found of given Id");
//       } else {
//     res.status(200).json(category);
//       }
// });
// //create category
//  const createCategory = asyncHandler(async (req: Request, res: Response) => {
//   const { categoryName, categoryImg, categoryDesc} = req.body;
//    if (!categoryName || !categoryImg || !categoryDesc) {
//     res.status(400);
//     throw new Error("All fields are required");
//   } else {
//     const category = await Category.create({
//         categoryName,
//         categoryImg,
//         categoryDesc
//     });
//      res.status(201).json({ message: "category created" });
//   }
// }); 


// //update category
// const updateCategory = asyncHandler( async (req: Request, res: Response) => {
//     const category = await Category.findById(req.params.id);
//     if (!category) {
//       res.status(404);
//       throw new Error("category not found of given Id");
//     } else {
//       const updateCategory = await Category.findByIdAndUpdate(
//         req.params.id,
//         req.body,
//         { new: true }
//       );
//       res.status(200).json(updateCategory);
//     }
//   });

//   //Delete category by ID
//   const deleteCategory = asyncHandler(async (req: Request, res: Response) =>{
//     const category = await Category.findById(req.params.id);
//     if(!category){
//         res.status(404);
//         throw new Error("category not found");
//     }else{
//         await Category.findByIdAndDelete(req.params.id);
//         res.status(200).json({message:"category deleted succesfully"});
//     }
//   });

//   //Upload catgeoryImg

//   const storage = multer.diskStorage({
//     destination: (req, file, cb) => {
//       cb(null, 'images');
//     },
//     filename: (req, file, cb) => {
//       const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
//       cb(null, `${file.fieldname}-${uniqueSuffix}-${file.originalname}`);
//     },
//   });
  
//   const upload = multer({ storage: storage });

//   const uploadCategoryImg = (req: Request, res: Response) => {
//     console.log(req.file);
//     if (!req.file) {
//       console.log(req.file);
//       res.status(400).json({ error: 'No file uploaded' });
//     } else {
//       console.log("in if condition");
//       const imageUrl = `${req.protocol}://${req.get('host')}/${req.file.filename}`;
//       res.status(200).json({ imageUrl });
//     }
//   };


  
  
  
  
//   export { getAllCategories,getCategoryById,createCategory,updateCategory,deleteCategory, uploadCategoryImg, upload};

import { Request, Response } from 'express';
import asyncHandler from 'express-async-handler';
import Category from '../models/categoryModel';
import multer, { StorageEngine } from 'multer';

// Get All Categories
const getAllCategories = asyncHandler(async (req: Request, res: Response) => {
  const category = await Category.find();
  res.status(200).json(category);
});

// Get category by ID
const getCategoryById = asyncHandler(async (req: Request, res: Response) => {
  const category = await Category.findById(req.params.id);
  if (!category) {
    res.status(404);
    throw new Error('category not found of given Id');
  } else {
    res.status(200).json(category);
  }
});

// Create category
const createCategory = asyncHandler(async (req: Request, res: Response) => {
  const { categoryName, categoryImg, categoryDesc } = req.body;
  if (!categoryName || !categoryImg || !categoryDesc) {
    res.status(400);
    throw new Error('All fields are required');
  } else {
    const category = await Category.create({
      categoryName,
      categoryImg,
      categoryDesc,
    });
    res.status(201).json({ message: 'category created' });
  }
});

// Update category
const updateCategory = asyncHandler(async (req: Request, res: Response) => {
  const category = await Category.findById(req.params.id);
  if (!category) {
    res.status(404);
    throw new Error('category not found of given Id');
  } else {
    const updateCategory = await Category.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).json(updateCategory);
  }
});

// Delete category by ID
const deleteCategory = asyncHandler(async (req: Request, res: Response) => {
  const category = await Category.findById(req.params.id);
  if (!category) {
    res.status(404);
    throw new Error('category not found');
  } else {
    await Category.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'category deleted successfully' });
  }
});

// Upload categoryImg
const storage: StorageEngine = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'images/category');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}-${file.originalname}`);
  },
});

const upload = multer({ storage });

const uploadCategoryImg = (req: Request, res: Response) => {
  console.log(req.file);
  if (!req.file) {
    console.log(req.file);
    res.status(400).json({ error: 'No file uploaded' });
  } else {
    console.log('in if condition');
    const imageUrl = `${req.protocol}://${req.get('host')}/${req.file.filename}`;
    res.status(200).json({ imageUrl });
  }
};

export {
  getAllCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory,
  uploadCategoryImg,
  upload,
};
