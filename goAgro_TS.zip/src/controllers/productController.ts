import { Request, Response } from 'express';
import asyncHandler from 'express-async-handler';
import Product from '../models/productModel';
import SubCategory from '../models/subcategoryModel';
import multer, { StorageEngine} from 'multer';


//Get All Products
const getAllProducts = asyncHandler(async (req: Request, res: Response) => {
const product = await Product.find();
res.status(200).json(product);
});

// Get Product by ID
const getProductById = asyncHandler(async (req: Request, res: Response) => {
    const product = await Product.findById(req.params.id);
    if (!product) {
        res.status(404);
        throw new Error("Product not found of given Id");
      } else {
    res.status(200).json(product);
      }
});
//create Product
 const createProduct = asyncHandler(async (req: Request, res: Response) => {
  const { subCategoryId, productName, price, quantity, gst, brand } = req.body;
   if (!subCategoryId || !productName || !price || !quantity || !gst || !brand) {
    res.status(400);
    throw new Error("All fields are required");
  } 

  const subCategory = await SubCategory.findById(subCategoryId)
  if(!subCategory){
    res.status(404);
    throw new Error("Invallid subcategory Id");   
  }
    console.log(req.body);
    const product = await Product.create({
      subCategoryId,
      productName,
      price,
      quantity,
      gst,
      brand
    });
     res.status(201).json({ message: "Product created" });
}); 


//update product
const updateProduct = asyncHandler( async (req: Request, res: Response) => {
    const product = await Product.findById(req.params.id);
    if (!product) {
      res.status(404);
      throw new Error("Product not found of given Id");
    } else {
      const updatedProduct = await Product.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
      );
      res.status(200).json(updatedProduct);
    }
  });

  //Delete ptoduct by ID
  const deleteProduct = asyncHandler(async (req: Request, res: Response) =>{
    const product = await Product.findById(req.params.id);
    if(!product){
        res.status(404);
        throw new Error("Product not found");
    }else{
        await Product.findByIdAndDelete(req.params.id);
        res.status(200).json({message:"Product deleted succesfully"});
    }
  });


  // Upload productImg
const storage: StorageEngine = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'images/product');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}-${file.originalname}`);
  },
});

const upload = multer({ storage });

const uploadProductImg = (req: Request, res: Response) => {
  console.log(req.file);
  if (!req.file) {
    console.log(req.file);
    res.status(400).json({ error: 'No file uploaded' });
  } else {
    console.log('in if condition');
    const imageUrl = `${req.protocol}://${req.get('host')}/${req.file.filename}`;
    res.status(200).json({ imageUrl });
  }
};

  
  export { 
    createProduct, 
    updateProduct, 
    getAllProducts, 
    getProductById, 
    deleteProduct,
    uploadProductImg,
    upload
  };