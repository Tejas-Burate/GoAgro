import { Request, Response } from 'express';
import asyncHandler from 'express-async-handler';
import Role from '../models/roleModel';

//Get All Roles
const getAllRoles = asyncHandler(async (req: Request, res: Response) => {
    const role = await Role.find();
    res.status(200).json(role);
})

//Get Role by Id

const getRoleById = asyncHandler(async(req: Request, res: Response)=>{
    const role = await Role.findById(req.params.id);
    if(!role){
        res.status(404);
        throw new Error("Role not found");
    } else {
        res.status(200).json(role);
    }
})


//Create Role
const createRole = asyncHandler(async(req: Request,res: Response) =>{
    const { roleName, status } = req.body;
    if(!roleName || !status){
        res.status(400);
        throw new Error("All fields are mandatory");       
    } else {
        const role = await Role.create({
            roleName,
            status
        });
        res.status(201).json({ message: "New Role created"});
    }
})

export {
    getAllRoles,
    getRoleById,
    createRole
}