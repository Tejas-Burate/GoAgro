import { Request, Response } from "express";
import asyncHandler from "express-async-handler";
import User from "../models/userModel";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

 // @desc Register a user
// @route POST /api/user/registerUser
// @access public
const registerUser = asyncHandler(async (req: Request, res: Response) => {
  console.log(req.body);
  const { userName, email, password, mobile } = req.body;
  if (!userName || !email || !password || !mobile) {
    res.status(400);
    throw new Error("All fields are mandatory!");
  }
  const userAvailable = await User.findOne({ email });
  if (userAvailable) {
    res.status(400);
    console.log("userAvailable");
    res.json("User already registered!");
  }
   // Hash Password
  const hashedPassword = await bcrypt.hash(password, 10);
  console.log("Hashed Password: ", hashedPassword);
   const user = await User.create({
    userName,
    email,
    password: hashedPassword,
  });
  console.log("User created successfully");
  res.status(201).json({ message: "User created successfully" });
});


const example = asyncHandler(async (req: Request, res: Response) => {
  console.log("Working");
});

 // @desc Login a user
// @route POST /api/user/loginUser
// @access public
const loginUser = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400);
    res.json({ message: "All fields are mandatory" });
    return;
  }
   const user = await User.findOne({ email });
  if (user && (await bcrypt.compare(password, user.password))) {
    const accessToken = jwt.sign(
      {
        user: {
          userName: user.userName,
          email: user.email,
          id: user.id,
        },
      },
      process.env.ACCESS_TOKEN_SECRET!,
      { expiresIn: "20m" }
    );
    // res.json({message : "Login successful"});
     res.status(200).json({message:"Login Successull", accessToken });
    return;
  }
   res.status(401).json({ message: "Invalid email or password" });
});
 // @desc Current user
// @route Post /api/user/currentUser
// @access private
const currentUser = asyncHandler(async (req: Request, res: Response) => {
  res.json({ message: "current user information" });
});
 export { registerUser, loginUser, currentUser, example };