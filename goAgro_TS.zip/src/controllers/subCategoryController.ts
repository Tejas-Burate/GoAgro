import { Request, Response } from 'express';
import asyncHandler from 'express-async-handler';
import SubCategory from '../models/subcategoryModel';
import Category from '../models/categoryModel';
import multer, { StorageEngine } from 'multer';

//Get All Categories
const getAllsubCategories = asyncHandler(async (req: Request, res: Response) => {
const category = await SubCategory.find();
res.status(200).json(category);
});

// Get category by ID
const getsubCategoryById = asyncHandler(async (req: Request, res: Response) => {
    const category = await SubCategory.findById(req.params.id);
    if (!category) {
        res.status(404);
        throw new Error("category not found of given Id");
      } else {
    res.status(200).json(category);
      }
});
//create category
 const createsubCategory = asyncHandler(async (req: Request, res: Response) => {
  const { 
    categoryId, 
    categoryName, 
    categoryImg, 
    categoryDesc
  } = req.body;

   if (!categoryId || !categoryName || !categoryImg || !categoryDesc) {
    res.status(400);
    throw new Error("All fields are required");
  } 
    const categoryF = await Category.findById(categoryId);
    if(!categoryF){
      res.status(400);
      throw new Error("Invalid category ID");      
    }
    const category = await SubCategory.create({
        categoryId,
        categoryName,
        categoryImg,
        categoryDesc
    });
     res.status(201).json({ message: "category created" });  
}); 

//update category
const updatesubCategory = asyncHandler( async (req: Request, res: Response) => {
    const category = await SubCategory.findById(req.params.id);
    if (!category) {
      res.status(404);
      throw new Error("category not found of given Id");
    } else {
      const updateCategory = await SubCategory.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
      );
      res.status(200).json(updateCategory);
    }
  });

  //Delete category by ID
  const deletesubCategory = asyncHandler(async (req: Request, res: Response) =>{
    const category = await SubCategory.findById(req.params.id);
    if(!category){
        res.status(404);
        throw new Error("Category not found");
    }else{
        await SubCategory.findByIdAndDelete(req.params.id);
        res.status(200).json({message:"Category deleted succesfully"});
    }
  });


  // Upload subCategoryImg
const storage: StorageEngine = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'images/SubCategory');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}-${file.originalname}`);
  },
});

const upload = multer({ storage });

const uploadSubCategoryImg = (req: Request, res: Response) => {
  console.log(req.file);
  if (!req.file) {
    console.log(req.file);
    res.status(400).json({ error: 'No file uploaded' });
  } else {
    console.log('in if condition');
    const imageUrl = `${req.protocol}://${req.get('host')}/${req.file.filename}`;
    res.status(200).json({ imageUrl });
  }
};

  export {
    createsubCategory, 
    updatesubCategory,
    getAllsubCategories, 
    getsubCategoryById, 
    deletesubCategory,
    uploadSubCategoryImg,
    upload
  };