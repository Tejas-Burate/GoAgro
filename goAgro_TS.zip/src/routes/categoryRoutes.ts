import express from "express";
import {
    createCategory, 
    updateCategory, 
    getAllCategories, 
    getCategoryById, 
    deleteCategory, 
    uploadCategoryImg, 
    upload
} from "../controllers/categoryController";


const router = express.Router();
router.get("/getAllCategories",getAllCategories);
router.get("/getCategoryById/:id",getCategoryById);
router.post("/createCategory",createCategory);
router.put("/updateCategory/:id",updateCategory);
router.delete("/deleteCategory/:id",deleteCategory);
router.post("/uploadCategoryImg",upload.single('categoryImg'),uploadCategoryImg);

export default router;