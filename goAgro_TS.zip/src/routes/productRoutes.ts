import express from "express";
import {
    createProduct, 
    updateProduct, 
    getAllProducts, 
    getProductById, 
    deleteProduct,
    uploadProductImg,
    upload
} from "../controllers/productController";

const router = express.Router();
router.get("/getAllProducts",getAllProducts);
router.get("/getProductById/:id",getProductById);
router.post("/createProduct",createProduct);
router.put("/updateProduct/:id",updateProduct);
router.delete("/deleteProduct/:id",deleteProduct);
router.post("/uploadProductImg",upload.single('productImg'),uploadProductImg);
export default router;