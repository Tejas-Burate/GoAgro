import express from "express";
import {
    createsubCategory, 
    updatesubCategory, 
    getAllsubCategories, 
    getsubCategoryById, 
    deletesubCategory,
    uploadSubCategoryImg,
    upload
} from "../controllers/subCategoryController";

const router = express.Router();
router.get("/getAllsubCategories",getAllsubCategories);
router.get("/getsubCategoryById/:id",getsubCategoryById);
router.post("/createsubCategory",createsubCategory);
router.put("/updatesubCategory/:id",updatesubCategory);
router.delete("/deletesubCategory/:id",deletesubCategory);
router.post("/uploadSubCategoryImg",upload.single('subCategoryImg'),uploadSubCategoryImg);

export default router;