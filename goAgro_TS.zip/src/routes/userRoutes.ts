import express from "express";
import { Request, Response } from "express";
import { example, registerUser, loginUser, currentUser } from "../controllers/userController";
const router = express.Router();
 
 router.post("/example", example);
 router.get("/currentUser", currentUser);
router.post("/registerUser", registerUser);
router.post("/loginUser", loginUser);
 export default router;