import express from 'express';
import {
    getAllRoles,
    getRoleById,
    createRole
} from "../controllers/roleController";

const router = express.Router();

router.get('/getAllRoles',getAllRoles);
router.get('/getRoleById/:id',getRoleById);
router.put('/createRole',createRole)

export default router;