import { Schema, model, Document } from "mongoose";

interface Category extends Document {
  categoryId: Schema.Types.ObjectId;
  categoryName: string;
  categoryImg: string;
  categoryDesc: string;
  createdAt: Date;
  updatedAt: Date;
}

const categorySchema = new Schema<Category>(
  {
    categoryName: {
      type: String,
      required: [true, "Please add the category name"],
    },
    categoryImg: {
      type: String,
      required: [true, "Please add the category img"],
      
    },
    categoryDesc: {
      type: String,
      required: [true, "Please add the category description"],
    },
  },
  {
    timestamps: true,
  }
);

export default model<Category>("Category", categorySchema);
