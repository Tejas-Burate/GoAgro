import { Schema, model, Document } from "mongoose";

interface Product extends Document {
  subCategoryId: Schema.Types.ObjectId;
  productName: string;
  price: number;
  quantity: number;
  gst: string;
  brand: string;
  createdAt: Date;
  updatedAt: Date;
}

const productSchema = new Schema<Product>(
  {
    subCategoryId: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: true
    },
    productName: {
      type: String,
      required: [true, "Please add the user name"],
    },
    price: {
      type: Number,
      required: [true, "Please add the user email address"],
    },
    quantity: {
      type: Number,
      required: [true, "Please add the user password"],
    },
    gst: {
      type: String,
      // required: [true, "Please add the mobile number"],
    },
    brand: {
      type: String,
    },
    
  },
  {
    timestamps: true,
  }
);

export default model<Product>("Product", productSchema);
