import { Schema, model, Document } from "mongoose";

interface Role extends Document {
  roleId: Schema.Types.ObjectId;
  roleName: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
}

const roleSchema = new Schema<Role>(
  {
    roleName: {
      type: String,
      required: true
    },
    status: {
      type: String,
      required: true
    }    
  },
  {
    timestamps: true,
  }
);

export default model<Role>("Role", roleSchema);
