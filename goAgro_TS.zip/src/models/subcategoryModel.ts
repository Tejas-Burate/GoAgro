import { Schema, model, Document } from "mongoose";

interface subCategory extends Document {
  categoryId: Schema.Types.ObjectId;
  categoryName: string;
  categoryImg: string;
  categoryDesc: string;
  createdAt: Date;
  updatedAt: Date;
}

const subCategorySchema = new Schema<subCategory>(
  {
    categoryId: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: true
    },
    categoryName: {
      type: String,
      required: [true, "Please add the category name"]
    },
    categoryImg: {
      type: String,
      required: [true, "Please add the sub category img"],
    },
    categoryDesc: {
      type: String,
      required: [true, "Please add the sub category description"]
    }
  },
  {
    timestamps: true
  }
);

export default model<subCategory>("subCategory", subCategorySchema);
