import { Schema, model, Document } from "mongoose";

interface User extends Document {
  user_id: Schema.Types.ObjectId;
  userName: string;
  email: string;
  password: string;
  mobile: number;
  otp: number;
  roleId: number;
  createdAt: Date;
  updatedAt: Date;
}

const userSchema = new Schema<User>(
  {
    userName: {
      type: String,
      required: [true, "Please add the user name"],
    },
    email: {
      type: String,
      required: [true, "Please add the user email address"],
      unique: true,
    },
    password: {
      type: String,
      required: [true, "Please add the user password"],
    },
    mobile: {
      type: Number,
      // required: [true, "Please add the mobile number"],
    },
    otp: {
      type: Number,
    },
    roleId: {
      type: Number,
    },
  },
  {
    timestamps: true,
  }
);

export default model<User>("User", userSchema);
