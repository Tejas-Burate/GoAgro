// import { Request, Response, NextFunction } from "express";
// import asyncHandler from "express-async-handler";
// import jwt from "jsonwebtoken";
//  const validateToken = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
//   let token;
//   let authHeader = req.headers.authorization;
//    if (authHeader && authHeader.startsWith("Bearer")) {
//     token = authHeader.split(" ")[1];
//     try {
//       console.log("Token:", token);
//       const decoded: any = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
//       console.log("Decoded:", decoded);
//       req.user = decoded.user;
//       next();
//     } catch (err) {
//       res.status(401).json({ message: "User is not authorized" });
//     }
//   } else {
//     res.status(401).json({ message: "User is not authorized" });
//   }
// });
//  export default validateToken;