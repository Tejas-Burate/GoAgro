export const constants = {
    VALIDATION_ERROR: 400 as const,
    UNAUTHORIZED: 401 as const,
    FORBIDDEN: 403 as const,
    NOT_FOUND: 404 as const,
    SERVER_ERROR: 500 as const,
};

export default constants;