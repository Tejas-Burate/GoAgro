{
    "compilerOptions":{
        "module": "NodeNext",
        "moduleResolution": "node",
        "baseUrl": "src",
        "outDir": "dist",
        "sourceMap":true,
        "noImplicitAny": true,
    },
    "include" :["/*"],
}